
  # AI Assistant Chat Integration

  This is a code bundle for AI Assistant Chat Integration. The original project is available at https://www.figma.com/design/grfh2wPmrd7Io3p3eDb1tv/AI-Assistant-Chat-Integration.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  