import { useState, useEffect, useRef } from 'react';
import { X, Send, Paperclip, Users, Bot, User, Circle, Plus, Hash } from 'lucide-react';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { ScrollArea } from './ui/scroll-area';
import { Avatar, AvatarFallback } from './ui/avatar';
import { Badge } from './ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from './ui/tabs';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from './ui/dropdown-menu';
import { Client } from '@stomp/stompjs';

// Mock 데이터: 실제로는 WebSocket을 통해 받아옵니다
const mockUsers = [
  { id: '1', name: '김간호사', status: 'online' as const },
  { id: '2', name: '이의사', status: 'away' as const },
  { id: '3', name: '박코디', status: 'online' as const },
];

const mockChatRooms = [
  { 
    id: 'room-1', 
    name: '개발팀 회의',
    participants: ['김간호사', '이의사', '박코디'],
    unreadCount: 3,
  },
  { 
    id: 'room-2', 
    name: 'Sprint 계획',
    participants: ['이의사', '박코디'],
    unreadCount: 0,
  },
  { 
    id: 'room-3', 
    name: 'OCR 프로젝트',
    participants: ['김간호사', '이의사'],
    unreadCount: 1,
  },
];

interface Message {
  id: string;
  sender: string;
  content: string;
  timestamp: Date;
  type: 'ai' | 'user' | 'system';
  file?: { name: string; url: string };
  roomId?: string;
}

interface User {
  id: string;
  name: string;
  status: 'online' | 'away' | 'offline';
}

interface ChatRoom {
  id: string;
  name: string;
  participants: string[];
  unreadCount: number;
}

interface ChatAssistantProps {
  onClose: () => void;
}

export function ChatAssistant({ onClose }: ChatAssistantProps) {
  const [mode, setMode] = useState<'ai' | 'chat'>('ai');
  const [messages, setMessages] = useState<Message[]>([
    {
      id: '1',
      sender: 'AI 어시스턴트',
      content: '안녕하세요! 무엇을 도와드릴까요?',
      timestamp: new Date(),
      type: 'ai',
    },
  ]);
  const [inputValue, setInputValue] = useState('');
  const [selectedFile, setSelectedFile] = useState<File | null>(null);
  const [activeUsers, setActiveUsers] = useState<User[]>(mockUsers);
  const [typingUsers, setTypingUsers] = useState<string[]>([]);
  const [chatRooms, setChatRooms] = useState<ChatRoom[]>(mockChatRooms);
  const [selectedRoom, setSelectedRoom] = useState<ChatRoom | null>(null);
  const stompClientRef = useRef<Client | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  // WebSocket 연결 (데모용 - 실제 백엔드 URL로 변경 필요)
  useEffect(() => {
    // const client = new Client({
    //   brokerURL: 'ws://localhost:8080/ws',
    //   reconnectDelay: 5000,
    //   heartbeatIncoming: 4000,
    //   heartbeatOutgoing: 4000,
    // });

    // client.onConnect = () => {
    //   console.log('Connected to WebSocket');
    //   client.subscribe('/topic/messages', (message) => {
    //     const newMessage = JSON.parse(message.body);
    //     setMessages((prev) => [...prev, newMessage]);
    //   });
    // };

    // client.activate();
    // stompClientRef.current = client;

    // return () => {
    //   client.deactivate();
    // };
  }, []);

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages]);

  const handleSendMessage = () => {
    if (!inputValue.trim() && !selectedFile) return;

    const newMessage: Message = {
      id: Date.now().toString(),
      sender: '나',
      content: inputValue,
      timestamp: new Date(),
      type: 'user',
      file: selectedFile
        ? { name: selectedFile.name, url: URL.createObjectURL(selectedFile) }
        : undefined,
      roomId: selectedRoom?.id,
    };

    setMessages([...messages, newMessage]);
    setInputValue('');
    setSelectedFile(null);

    // WebSocket으로 메시지 전송
    // if (stompClientRef.current?.connected) {
    //   stompClientRef.current.publish({
    //     destination: '/app/chat',
    //     body: JSON.stringify(newMessage),
    //   });
    // }

    // AI 응답 시뮬레이션
    if (mode === 'ai') {
      setTimeout(() => {
        setMessages((prev) => [
          ...prev,
          {
            id: (Date.now() + 1).toString(),
            sender: 'AI 어시스턴트',
            content: '네, 알겠습니다. 도와드리겠습니다.',
            timestamp: new Date(),
            type: 'ai',
          },
        ]);
      }, 1000);
    }
  };

  const handleFileSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      setSelectedFile(file);
    }
  };

  const getStatusColor = (status: User['status']) => {
    switch (status) {
      case 'online':
        return 'bg-green-500';
      case 'away':
        return 'bg-yellow-500';
      default:
        return 'bg-gray-400';
    }
  };

  return (
    <div className="fixed right-0 top-0 h-full w-96 bg-white border-l border-gray-200 shadow-2xl flex flex-col z-50">
      {/* Header */}
      <div className="bg-[#8B5CF6] text-white p-4 flex items-center justify-between">
        <div className="flex items-center gap-2">
          <Bot className="w-5 h-5" />
          <h2 className="font-semibold">
            {mode === 'ai' ? 'AI 어시스턴트' : '실시간 대화'}
          </h2>
        </div>
        <Button
          variant="ghost"
          size="sm"
          onClick={onClose}
          className="text-white hover:bg-white/20"
        >
          <X className="w-5 h-5" />
        </Button>
      </div>

      {/* Mode Toggle */}
      <Tabs value={mode} onValueChange={(v) => setMode(v as 'ai' | 'chat')} className="border-b">
        <TabsList className="w-full rounded-none bg-transparent h-12">
          <TabsTrigger value="ai" className="flex-1 data-[state=active]:bg-[#8B5CF6]/10">
            <Bot className="w-4 h-4 mr-2" />
            AI 모드
          </TabsTrigger>
          <TabsTrigger value="chat" className="flex-1 data-[state=active]:bg-[#8B5CF6]/10">
            <Users className="w-4 h-4 mr-2" />
            대화 모드
          </TabsTrigger>
        </TabsList>
      </Tabs>

      {/* Active Users (Chat Mode) */}
      {mode === 'chat' && (
        <div className="p-3 bg-gray-50 border-b">
          <div className="flex items-center gap-2 flex-wrap">
            <span className="text-xs text-gray-600 font-medium">활성 사용자:</span>
            {activeUsers.map((user) => (
              <div key={user.id} className="flex items-center gap-1.5 bg-white px-2 py-1 rounded-full border">
                <Circle className={`w-2 h-2 fill-current ${getStatusColor(user.status)}`} />
                <span className="text-xs">{user.name}</span>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Chat Rooms (Chat Mode) */}
      {mode === 'chat' && (
        <div className="p-3 bg-white border-b">
          <div className="flex items-center justify-between mb-2">
            <div className="flex items-center gap-2">
              <Hash className="w-4 h-4 text-gray-500" />
              <span className="text-sm font-medium text-gray-700">
                {selectedRoom ? selectedRoom.name : '채팅방 선택'}
              </span>
              {selectedRoom && selectedRoom.participants.length > 0 && (
                <span className="text-xs text-gray-500">
                  ({selectedRoom.participants.length}명)
                </span>
              )}
            </div>
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button variant="outline" size="sm">
                  채팅방 {chatRooms.filter(r => r.unreadCount > 0).length > 0 && (
                    <Badge className="ml-2 bg-red-500 text-white text-xs h-5 px-1.5">
                      {chatRooms.reduce((sum, r) => sum + r.unreadCount, 0)}
                    </Badge>
                  )}
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="end" className="w-64">
                <DropdownMenuLabel>채팅방 목록</DropdownMenuLabel>
                <DropdownMenuSeparator />
                {chatRooms.map((room) => (
                  <DropdownMenuItem
                    key={room.id}
                    onClick={() => {
                      setSelectedRoom(room);
                      // 채팅방 선택 시 읽지 않은 메시지 초기화
                      setChatRooms(prev => prev.map(r => 
                        r.id === room.id ? { ...r, unreadCount: 0 } : r
                      ));
                      // 해당 채팅방 메시지 로드 (데모용)
                      setMessages([
                        {
                          id: Date.now().toString(),
                          sender: 'System',
                          content: `${room.name} 채팅방에 입장했습니다.`,
                          timestamp: new Date(),
                          type: 'system',
                          roomId: room.id,
                        },
                      ]);
                    }}
                    className={selectedRoom?.id === room.id ? 'bg-gray-100' : ''}
                  >
                    <div className="flex items-center justify-between w-full">
                      <div className="flex items-center gap-2">
                        <Hash className="w-4 h-4 text-gray-500" />
                        <div>
                          <p className="font-medium">{room.name}</p>
                          <p className="text-xs text-gray-500">
                            {room.participants.join(', ')}
                          </p>
                        </div>
                      </div>
                      {room.unreadCount > 0 && (
                        <Badge className="bg-red-500 text-white text-xs">
                          {room.unreadCount}
                        </Badge>
                      )}
                    </div>
                  </DropdownMenuItem>
                ))}
                <DropdownMenuSeparator />
                <DropdownMenuItem className="text-blue-600">
                  <Plus className="w-4 h-4 mr-2" />
                  새 채팅방 만들기
                </DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>
          </div>
          
          {/* 현재 채팅방 참여자 */}
          {selectedRoom && (
            <div className="flex items-center gap-2 flex-wrap">
              <span className="text-xs text-gray-600 font-medium">참여자:</span>
              {selectedRoom.participants.map((participant, idx) => {
                const user = activeUsers.find(u => u.name === participant);
                return (
                  <div key={idx} className="flex items-center gap-1.5 bg-gray-100 px-2 py-1 rounded-full">
                    <Circle className={`w-2 h-2 fill-current ${user ? getStatusColor(user.status) : 'bg-gray-400'}`} />
                    <span className="text-xs">{participant}</span>
                  </div>
                );
              })}
            </div>
          )}
        </div>
      )}

      {/* Messages */}
      <ScrollArea className="flex-1 p-4">
        <div className="space-y-4">
          {messages.map((message) => (
            <div
              key={message.id}
              className={`flex gap-2 ${message.type === 'user' ? 'flex-row-reverse' : message.type === 'system' ? 'justify-center' : ''}`}
            >
              {message.type !== 'system' && (
                <Avatar className="w-8 h-8 flex-shrink-0">
                  <AvatarFallback className={message.type === 'ai' ? 'bg-[#8B5CF6]' : 'bg-blue-500'}>
                    {message.type === 'ai' ? <Bot className="w-4 h-4 text-white" /> : <User className="w-4 h-4 text-white" />}
                  </AvatarFallback>
                </Avatar>
              )}
              
              {message.type === 'system' ? (
                <div className="text-center">
                  <div className="inline-block px-4 py-2 bg-gray-200 rounded-full">
                    <p className="text-xs text-gray-600">{message.content}</p>
                  </div>
                </div>
              ) : (
                <div className={`flex-1 ${message.type === 'user' ? 'flex flex-col items-end' : ''}`}>
                  <div className="flex items-center gap-2 mb-1">
                    <span className="text-xs text-gray-600">{message.sender}</span>
                    <span className="text-xs text-gray-400">
                      {message.timestamp.toLocaleTimeString('ko-KR', {
                        hour: '2-digit',
                        minute: '2-digit',
                      })}
                    </span>
                  </div>
                  <div
                    className={`px-3 py-2 rounded-lg max-w-xs ${
                      message.type === 'user'
                        ? 'bg-[#8B5CF6] text-white'
                        : 'bg-gray-100 text-gray-900'
                    }`}
                  >
                    <p className="text-sm">{message.content}</p>
                    {message.file && (
                      <div className="mt-2 pt-2 border-t border-white/20">
                        <div className="flex items-center gap-2 text-xs">
                          <Paperclip className="w-3 h-3" />
                          <span>{message.file.name}</span>
                        </div>
                      </div>
                    )}
                  </div>
                </div>
              )}
            </div>
          ))}
          {typingUsers.length > 0 && mode === 'chat' && (
            <div className="flex gap-2 items-center text-sm text-gray-500">
              <div className="flex gap-1">
                <span className="w-2 h-2 bg-gray-400 rounded-full animate-bounce" style={{ animationDelay: '0ms' }} />
                <span className="w-2 h-2 bg-gray-400 rounded-full animate-bounce" style={{ animationDelay: '150ms' }} />
                <span className="w-2 h-2 bg-gray-400 rounded-full animate-bounce" style={{ animationDelay: '300ms' }} />
              </div>
              <span>{typingUsers.join(', ')}가 입력 중입니다...</span>
            </div>
          )}
          <div ref={messagesEndRef} />
        </div>
      </ScrollArea>

      {/* Input Area */}
      <div className="border-t p-4 bg-gray-50">
        {selectedFile && (
          <div className="mb-2 p-2 bg-white rounded border flex items-center justify-between">
            <div className="flex items-center gap-2 text-sm">
              <Paperclip className="w-4 h-4 text-gray-500" />
              <span className="text-gray-700">{selectedFile.name}</span>
            </div>
            <Button
              variant="ghost"
              size="sm"
              onClick={() => setSelectedFile(null)}
            >
              <X className="w-4 h-4" />
            </Button>
          </div>
        )}
        <div className="flex gap-2">
          <input
            type="file"
            ref={fileInputRef}
            onChange={handleFileSelect}
            className="hidden"
          />
          <Button
            variant="outline"
            size="icon"
            onClick={() => fileInputRef.current?.click()}
            className="flex-shrink-0"
          >
            <Paperclip className="w-4 h-4" />
          </Button>
          <Input
            value={inputValue}
            onChange={(e) => setInputValue(e.target.value)}
            onKeyPress={(e) => e.key === 'Enter' && handleSendMessage()}
            placeholder={mode === 'ai' ? 'AI에게 질문하기...' : '메시지 입력...'}
            className="flex-1"
          />
          <Button
            onClick={handleSendMessage}
            className="bg-[#8B5CF6] hover:bg-[#7C3AED] flex-shrink-0"
          >
            <Send className="w-4 h-4" />
          </Button>
        </div>
      </div>
    </div>
  );
}