import { useState } from 'react';
import { ChatAssistant } from './components/ChatAssistant';
import { Button } from './components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from './components/ui/card';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, LineChart, Line } from 'recharts';
import { MessageSquare, AlertTriangle, Activity, TrendingUp } from 'lucide-react';

// Mock 데이터
const waterFallData = [
  { name: '1주', 남: 85, 여: 70 },
  { name: '2주', 남: 90, 여: 75 },
  { name: '3주', 남: 70, 여: 65 },
  { name: '4주', 남: 80, 여: 70 },
  { name: '5주', 남: 75, 여: 68 },
  { name: '6주', 남: 88, 여: 72 },
];

const velocityData = [
  { name: 'Sprint 1', velocity: 35 },
  { name: 'Sprint 2', velocity: 42 },
  { name: 'Sprint 3', velocity: 44 },
  { name: 'Sprint 4', velocity: 38 },
  { name: 'Sprint 5', velocity: 45 },
];

const burndownData = [
  { name: 'Day 1', ideal: 100, actual: 100 },
  { name: 'Day 2', ideal: 90, actual: 92 },
  { name: 'Day 3', ideal: 80, actual: 85 },
  { name: 'Day 4', ideal: 70, actual: 72 },
  { name: 'Day 5', ideal: 60, actual: 60 },
  { name: 'Day 6', ideal: 50, actual: 48 },
  { name: 'Day 7', ideal: 40, actual: 35 },
  { name: 'Day 8', ideal: 30, actual: 22 },
  { name: 'Day 9', ideal: 20, actual: 15 },
  { name: 'Day 10', ideal: 0, actual: 5 },
];

export default function App() {
  const [showAssistant, setShowAssistant] = useState(true);

  return (
    <div className="min-h-screen bg-gray-50 flex">
      {/* Sidebar */}
      <aside className="w-64 bg-blue-600 text-white flex flex-col">
        <div className="p-6">
          <h1 className="text-xl font-bold">InsureTech AI-PMS</h1>
          <p className="text-sm text-blue-200 mt-1">Project Management System</p>
        </div>
        
        <nav className="flex-1 px-4 space-y-2">
          <a href="#" className="flex items-center gap-3 px-4 py-3 rounded-lg bg-blue-700 hover:bg-blue-700 transition">
            <Activity className="w-5 h-5" />
            <span>대시보드</span>
          </a>
          <a href="#" className="flex items-center gap-3 px-4 py-3 rounded-lg hover:bg-blue-700 transition">
            <TrendingUp className="w-5 h-5" />
            <span>프로젝트 분석</span>
          </a>
          <a href="#" className="flex items-center gap-3 px-4 py-3 rounded-lg hover:bg-blue-700 transition">
            <AlertTriangle className="w-5 h-5" />
            <span>위험 관리</span>
          </a>
          <a href="#" className="flex items-center gap-3 px-4 py-3 rounded-lg hover:bg-blue-700 transition">
            <MessageSquare className="w-5 h-5" />
            <span>메시지</span>
          </a>
        </nav>

        <div className="p-4 border-t border-blue-500">
          <p className="text-sm text-blue-200">환자 관리 시스템</p>
        </div>
      </aside>

      {/* Main Content */}
      <main className="flex-1 overflow-auto">
        {/* Top Bar */}
        <header className="bg-white border-b border-gray-200 px-8 py-4 flex items-center justify-between">
          <div>
            <h2 className="text-xl font-semibold text-gray-900">
              AI 기반 순환형 자가운동 치료 프로젝트
            </h2>
            <p className="text-sm text-gray-500 mt-1">Project Code: #9-2025-09</p>
          </div>
          <div className="flex items-center gap-4">
            <Button
              onClick={() => setShowAssistant(!showAssistant)}
              className="bg-[#8B5CF6] hover:bg-[#7C3AED]"
            >
              <MessageSquare className="w-4 h-4 mr-2" />
              AI 어시스턴트
            </Button>
            <div className="flex items-center gap-2">
              <div className="w-10 h-10 rounded-full bg-purple-600 flex items-center justify-center text-white">
                김
              </div>
              <div>
                <p className="text-sm font-medium text-gray-900">김관리자</p>
                <p className="text-xs text-gray-500">관리자</p>
              </div>
            </div>
          </div>
        </header>

        {/* Dashboard Content */}
        <div className="p-8" style={{ marginRight: showAssistant ? '384px' : '0' }}>
          {/* Stats Cards */}
          <div className="grid grid-cols-4 gap-6 mb-8">
            <Card>
              <CardContent className="p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm text-gray-600">프로젝트 진도율</p>
                    <p className="text-3xl font-bold text-blue-600 mt-2">62%</p>
                  </div>
                  <div className="w-12 h-12 rounded-full bg-blue-100 flex items-center justify-center">
                    <Activity className="w-6 h-6 text-blue-600" />
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardContent className="p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm text-gray-600">일정 준수율</p>
                    <p className="text-3xl font-bold text-green-600 mt-2">58%</p>
                  </div>
                  <div className="w-12 h-12 rounded-full bg-green-100 flex items-center justify-center">
                    <TrendingUp className="w-6 h-6 text-green-600" />
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardContent className="p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm text-gray-600">품질 지수</p>
                    <p className="text-3xl font-bold text-yellow-600 mt-2">7</p>
                    <p className="text-xs text-gray-500 mt-1">Open Defects</p>
                  </div>
                  <div className="w-12 h-12 rounded-full bg-yellow-100 flex items-center justify-center">
                    <AlertTriangle className="w-6 h-6 text-yellow-600" />
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardContent className="p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm text-gray-600">리소스 활용</p>
                    <p className="text-3xl font-bold text-purple-600 mt-2">142</p>
                    <p className="text-xs text-gray-500 mt-1">팀 멤버</p>
                  </div>
                  <div className="w-12 h-12 rounded-full bg-purple-100 flex items-center justify-center">
                    <Activity className="w-6 h-6 text-purple-600" />
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Charts */}
          <div className="grid grid-cols-2 gap-6 mb-8">
            {/* Waterfall Chart */}
            <Card>
              <CardHeader>
                <CardTitle className="text-lg">단계별 진행 률 (Waterfall View)</CardTitle>
              </CardHeader>
              <CardContent>
                <ResponsiveContainer width="100%" height={250}>
                  <BarChart data={waterFallData}>
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis dataKey="name" />
                    <YAxis />
                    <Tooltip />
                    <Bar dataKey="남" fill="#60A5FA" />
                    <Bar dataKey="여" fill="#93C5FD" />
                  </BarChart>
                </ResponsiveContainer>
              </CardContent>
            </Card>

            {/* Velocity Chart */}
            <Card>
              <CardHeader>
                <CardTitle className="text-lg">스프린트 속도 (Sprint Velocity)</CardTitle>
              </CardHeader>
              <CardContent>
                <ResponsiveContainer width="100%" height={250}>
                  <BarChart data={velocityData}>
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis dataKey="name" />
                    <YAxis />
                    <Tooltip />
                    <Bar dataKey="velocity" fill="#A78BFA" />
                  </BarChart>
                </ResponsiveContainer>
              </CardContent>
            </Card>
          </div>

          {/* Burndown Chart */}
          <Card className="mb-8">
            <CardHeader>
              <CardTitle className="text-lg">소멸 차트 (Current Sprint Burndown)</CardTitle>
              <p className="text-sm text-gray-500">Sprint 5 (Day 10 of 14)</p>
            </CardHeader>
            <CardContent>
              <ResponsiveContainer width="100%" height={300}>
                <LineChart data={burndownData}>
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis dataKey="name" />
                  <YAxis />
                  <Tooltip />
                  <Line type="monotone" dataKey="ideal" stroke="#9CA3AF" strokeDasharray="5 5" name="이상 경로" />
                  <Line type="monotone" dataKey="actual" stroke="#3B82F6" strokeWidth={2} name="실제 경로" />
                </LineChart>
              </ResponsiveContainer>
            </CardContent>
          </Card>

          {/* AI Insights */}
          <Card className="border-blue-200 bg-blue-50">
            <CardHeader>
              <div className="flex items-center gap-2">
                <Activity className="w-5 h-5 text-blue-600" />
                <CardTitle className="text-lg">AI 시스템</CardTitle>
              </div>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                <div className="bg-white p-4 rounded-lg border border-blue-200 flex items-start gap-3">
                  <AlertTriangle className="w-5 h-5 text-yellow-600 mt-0.5" />
                  <div>
                    <p className="font-medium text-gray-900">위험 경고</p>
                    <p className="text-sm text-gray-600 mt-1">
                      OKR 프로토 타입 추가 일정이 지연되고 있습니다. 팀장과 조정이 필요합니다.
                    </p>
                  </div>
                </div>

                <div className="bg-white p-4 rounded-lg border border-blue-200 flex items-start gap-3">
                  <TrendingUp className="w-5 h-5 text-green-600 mt-0.5" />
                  <div>
                    <p className="font-medium text-gray-900">추천 조건</p>
                    <p className="text-sm text-gray-600 mt-1">
                      현재 속도를 유지하면 Sprint 6에서 목표 달성 가능합니다.
                    </p>
                  </div>
                </div>

                <div className="bg-white p-4 rounded-lg border border-blue-200 flex items-start gap-3">
                  <MessageSquare className="w-5 h-5 text-blue-600 mt-0.5" />
                  <div>
                    <p className="font-medium text-gray-900">권장 사항</p>
                    <p className="text-sm text-gray-600 mt-1">
                      다음 스프린트 계획 시 Augmentation AI 기능의 리팩토링을 고려하세요.
                    </p>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Recent Activity */}
          <Card className="mt-8">
            <CardHeader>
              <CardTitle className="text-lg">최근 활동</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div className="flex items-start gap-3 pb-4 border-b">
                  <div className="w-2 h-2 rounded-full bg-green-500 mt-2" />
                  <div className="flex-1">
                    <p className="text-sm text-gray-900">
                      <span className="font-medium">이의사</span>님이 OCR 프로토 타입 추가를 완료했습니다
                    </p>
                    <p className="text-xs text-gray-500 mt-1">2시간 전</p>
                  </div>
                </div>

                <div className="flex items-start gap-3 pb-4 border-b">
                  <div className="w-2 h-2 rounded-full bg-blue-500 mt-2" />
                  <div className="flex-1">
                    <p className="text-sm text-gray-900">
                      <span className="font-medium">김간호사</span>님이 새 Sprint 미팅을 예약했습니다
                    </p>
                    <p className="text-xs text-gray-500 mt-1">4시간 전</p>
                  </div>
                </div>

                <div className="flex items-start gap-3">
                  <div className="w-2 h-2 rounded-full bg-purple-500 mt-2" />
                  <div className="flex-1">
                    <p className="text-sm text-gray-900">
                      <span className="font-medium">박코디</span>님이 코드 리뷰 요청을 보냈습니다
                    </p>
                    <p className="text-xs text-gray-500 mt-1">6시간 전</p>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      </main>

      {/* AI Assistant Panel */}
      {showAssistant && <ChatAssistant onClose={() => setShowAssistant(false)} />}
    </div>
  );
}
